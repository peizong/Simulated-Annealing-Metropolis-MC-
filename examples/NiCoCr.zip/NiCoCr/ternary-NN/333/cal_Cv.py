#!/nfs/apps/Compilers/Python/Anaconda/2.7/bin/python

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import UnivariateSpline

data=np.genfromtxt("Cv.dat",skip_header=0)

x,y= data[:,0], data[:,2]
xr,yr=x[::-1],y[::-1]
s= UnivariateSpline(xr, yr)
xs=np.linspace(np.min(xr),np.max(xr),10*len(xr))
ys=s(xs)
dydx=np.diff(ys) #/np.diff(xs)
dx=np.delete(xs,len(xs)-1)
plt.subplot(121)
plt.plot(np.asarray(xr), np.asarray(yr))
plt.plot(xs, ys)
plt.subplot(122)
plt.plot(dx,dydx)
plt.show()
