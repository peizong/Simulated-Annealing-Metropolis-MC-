#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
using namespace std;

vector<string> split(string str, char delimiter) {
  vector<string> internal;
  stringstream ss(str); // Turn the string into a stream.
  string tok;
 
  while(getline(ss, tok, delimiter)) {
    internal.push_back(tok);
  }
}
int main ( )
{
	string line;

	int i = 0;

	vector < string > v;

	ifstream fin;

	fin.open( ( "incar" ) );

	if ( fin.is_open())
	{
		while ( getline ( fin, line ))
		{
			stringstream ss ( line );

			if ( getline ( ss, line))
			{
				v.push_back( line );
			}
		}

		while ( true )
		{
			if ( i == v.size())
			{
				break;
			}
                        vector <string> splitted = split(v[i], ' ');
			cout << v [ i ]<<" "<<splitted[0]<<" "<<splitted[1] << "\n";
			i++;
		}

        }
}
